def format_email(email_data):
    # Utility function to clean and format email data (optional)
    return {
        "id": email_data.get("id"),
        "snippet": email_data.get("snippet"),
        "subject": email_data.get("subject"),
        "from": email_data.get("from"),
    }
