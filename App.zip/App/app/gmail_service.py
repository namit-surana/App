from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

def authenticate_gmail():
    creds = None
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)
    return build('gmail', 'v1', credentials=creds)

def fetch_emails(service):
    try:
        results = service.users().messages().list(userId='me').execute()
        messages = results.get('messages', [])
        emails = []

        for message in messages:
            msg = service.users().messages().get(userId='me', id=message['id']).execute()
            headers = msg['payload']['headers']

            # Extract Subject and From headers safely
            subject = next((header['value'] for header in headers if header['name'] == 'Subject'), '(No Subject)')
            sender = next((header['value'] for header in headers if header['name'] == 'From'), '(Unknown Sender)')

            emails.append({
                'id': msg['id'],
                'snippet': msg.get('snippet', '(No Snippet)'),
                'subject': subject,
                'from': sender
            })

        return emails
    except Exception as e:
        print(f"Error fetching emails: {e}")
        return {"error": "Failed to fetch emails"}

