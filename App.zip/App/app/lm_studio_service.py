import requests

def process_with_llm(content, tone):
    # Adjust the URL to match your LM Studio API
    url = 'http://10.18.203.250:1234/v1/models'
    payload = {'content': content, 'tone': tone}

    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        return response.json().get('category', 'Unknown')
    except requests.RequestException as e:
        print(f"Error connecting to LM Studio: {e}")
        return "Error"
