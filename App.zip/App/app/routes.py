from flask import Blueprint, request, jsonify
from .gmail_service import authenticate_gmail, fetch_emails
import requests

api = Blueprint('api', __name__)

# LM Studio Configuration
LM_STUDIO_URL = "http://10.18.203.250:1234/v1/chat/completions"
MODEL_NAME = "your-model-identifier"  # Replace with your model's identifier

# Predefined Email Categories
EMAIL_CATEGORIES = [
    "Personal Emails", "Work-Related Emails", "Promotional Emails",
    "Transactional Emails", "Newsletters", "Notifications", "Spam Emails",
    "Support and Customer Service Emails", "Academic or Educational Emails",
    "Social Media Updates", "Financial Emails", "Legal and Compliance Emails",
    "Government and Official Emails", "Event Invitations", "Feedback or Survey Emails",
    "Health and Wellness Emails", "Marketing Automation Emails",
    "Technical Updates or Reports", "Recruitment and Career Emails", "Miscellaneous"
]


# Root Endpoint
@api.route('/')
def index():
    return "Welcome to the Email Management API!"

@api.route('/emails/respond/<email_id>', methods=['POST'])
def generate_response(email_id):
    try:
        # Fetch emails from Gmail
        service = authenticate_gmail()
        messages = fetch_emails(service)

        # Find the email with the given ID
        email = next((msg for msg in messages if msg['id'] == email_id), None)
        if not email:
            return jsonify({"error": "Email not found"}), 404

        # Extract subject and snippet
        subject = email.get('subject', '(No Subject)')
        snippet = email.get('snippet', '(No Snippet)')

        # Get tone from request body
        request_data = request.json
        tone = request_data.get('tone', 'Standard')

        # Check if the tone is valid
        valid_tones = ["Standard", "Fluency", "Natural", "Formal", "Academic", "Simple", "Creative"]
        if tone not in valid_tones:
            return jsonify({"error": f"Invalid tone specified. Valid tones are: {', '.join(valid_tones)}"}), 400

        # Prepare prompt for LM Studio
        prompt = f"""Generate a response to the following email using a {tone} tone:

Subject: {subject}
Snippet: {snippet}

Response:
"""
        # Send request to LM Studio
        response = process_with_llm(prompt)

        # Return the generated response
        return jsonify({
            "email_id": email_id,
            "tone": tone,
            "response": response
        })
    except Exception as e:
        print(f"Error generating response: {e}")
        return jsonify({"error": "Internal Server Error"}), 500

# Fetch Emails
@api.route('/emails', methods=['GET'])
def get_emails():
    try:
        # Fetch emails from Gmail
        service = authenticate_gmail()
        messages = fetch_emails(service)
        return jsonify(messages)
    except Exception as e:
        print(f"Error fetching emails: {e}")
        return jsonify({"error": "Internal Server Error"}), 500

@api.route('/emails/categorized/<email_id>', methods=['GET'])
def get_categorized_email_by_id(email_id):
    try:
        # Fetch emails from Gmail
        service = authenticate_gmail()
        messages = fetch_emails(service)

        # Find the email with the given ID
        email = next((msg for msg in messages if msg['id'] == email_id), None)
        if not email:
            return jsonify({"error": "Email not found"}), 404

        # Extract subject and snippet for categorization
        subject = email.get('subject', '(No Subject)')
        snippet = email.get('snippet', '(No Snippet)')

        # Prepare prompt for LM Studio
        prompt = f"""Categorize the following email into one of the categories:
{", ".join(EMAIL_CATEGORIES)}.

Subject: {subject}
Snippet: {snippet}

Category:
"""
        # Categorize using LM Studio
        category = process_with_llm(prompt)
        email['category'] = category

        return jsonify(email)
    except Exception as e:
        print(f"Error categorizing email: {e}")
        return jsonify({"error": "Internal Server Error"}), 500



# Helper Function: LM Studio Interaction
def process_with_llm(prompt):
    try:
        payload = {
            "model": MODEL_NAME,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7
        }
        response = requests.post(LM_STUDIO_URL, json=payload)
        response.raise_for_status()
        return response.json()['choices'][0]['message']['content'].strip()
    except Exception as e:
        print(f"Error connecting to LM Studio: {e}")
        return "Miscellaneous"  # Default category for errors
